const AWS = require("aws-sdk");

const dynamodb = new AWS.DynamoDB.DocumentClient();

 
exports.handler = async (event) => {
    
     console.log(event.body,'here')
    const requestBody = JSON.parse(event.body);
    
    
    
    console.log(requestBody,'here')
    
    const book = {
        TableName: 'books',
        Item: {
            bookID: Date.now().toString(),
            BookTitle: requestBody.bookTitle,
            Author: requestBody.author,
            Rating: requestBody.rating,
            Genre: requestBody.genre
        }
    };

    try {
        await dynamodb.put(book).promise();
        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Review submitted successfully' })
        };
    } catch (error) {
        console.log(error)
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Error submitting review' })
        };
    }
};